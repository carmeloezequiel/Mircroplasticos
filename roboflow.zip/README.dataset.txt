# Microplastic Dataset > 2022-01-02 7:40pm
https://universe.roboflow.com/panats-mp-project/microplastic-dataset

Provided by a Roboflow user
License: Public Domain

